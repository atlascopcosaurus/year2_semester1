<!DOCTYPE html>
<html>
<head>
    <title>Registration Successful</title>
</head>
<body>

<h1>Registration Successful!</h1>
<p>Thank you for registering.</p>

</body>
</html>